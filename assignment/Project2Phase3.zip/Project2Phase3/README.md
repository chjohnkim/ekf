Please catkin make the three packages:
-ekf
-optical_flow
-tag_detector

Download a bag file into (/ekf/bag) and modify bag name in the launch file in (/ekf/launch).
